#!/system/bin/sh
MODDIR=${0%/*}
PKG="com.garena.game.codm"
D="/data/data/$PKG/files"
i=0
while [ ! -d "$D" ] && [ "$i" -lt 120 ]; do
  sleep 2
  i=$((i + 1))
done
[ -d "$D" ] || exit 0
# Native payload requires mode=4. Flat strength 4=Extreme; ttsize 3=Huge.
for item in "mode 4" "near 1" "bias 0" "blk 0" "style 0" "flat 4" "testtex 0" "ttsize 3" "ttsm 0" "delay 0" "hookdelay 0" "scale 0" "fps 0" "minsz 64" "sedge 1"; do
  set -- $item
  printf '%s\\n' "$2" > "$D/$1.txt" || exit 1
  chmod 666 "$D/$1.txt" 2>/dev/null
  chcon --reference="$D" "$D/$1.txt" 2>/dev/null
done
printf 'Flat=Extreme (4), Pixel size=Huge (3), native mode=4\\n' > "$MODDIR/auto-applied.txt"
exit 0
