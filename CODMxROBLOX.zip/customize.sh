#!/system/bin/sh
SKIPUNZIP=0
ui_print "- CODM X ROBLOX | 69 position"
ui_print "- Fixed preset: Flat Extreme + Huge pixels"
ui_print "- No WebUI; settings are applied automatically at boot."
ui_print "- Requires arm64 and an enabled Zygisk-compatible environment."
if [ "$ARCH" != "arm64" ] && [ -z "$KSU" ] && [ -z "$APATCH" ]; then
  abort "! Only arm64 phones are supported (device: $ARCH)"
fi
if [ ! -f "$MODPATH/zygisk/arm64-v8a.so" ]; then
  abort "! zygisk/arm64-v8a.so is missing."
fi
set_perm "$MODPATH/service.sh" 0 0 0755
ui_print "- Install, reboot, then launch CODM."
